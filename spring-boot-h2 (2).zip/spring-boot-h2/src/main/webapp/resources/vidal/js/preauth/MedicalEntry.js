
var A;
var B;



          /*Add Pcs Details */

var pcsDtlArr = new Array(); 
function addpcsDtls(){	
	
		var pcsObj=new Object();
			
	var varPcsSeq= document.getElementById('pcsCodeSeqID').value;
	if(varPcsSeq==null||varPcsSeq==""||varPcsSeq.length==0){
		alert("Please search and select pcs code");
		return;
	}
	
	pcsObj.pcsCodeSeqID=document.getElementById('pcsCodeSeqID').value;
	pcsObj.pcsCodeLabel=document.getElementById('pcsCodeLabel').value;
	pcsObj.pcsCodeDesc=document.getElementById('pcsCodeDesc').value;
	
	pcsDtlArr[pcsDtlArr.length]=pcsObj; // adding element to array
		
		 document.getElementById('pcsSearchID').value=''; //Making the text box blank
		 document.getElementById('pcsCodeSeqID').value='';
		 document.getElementById('pcsCodeLabel').value='';
		 document.getElementById('pcsCodeDesc').value='';
		 displPcsDtla(); // displaying the array elements
	}

/*Display  ICD  Details */
function disp1IcdDtls(){			  		  	 
	  A = "<div class='vd-grid-style-basic'>";
	  A += "<table class='table table-basic' id='123'>";
	  A += "<thead>";
	  A += "<tr>";
	  A += "<th id='1'>Ailment</th>";
	  A += "<th id='2'>ICD Code</th>";
	  A += "<th id='3'>Procedures</th>";
	  A += "<th id='4'>Diagnosis Name</th>";
	  A += "<th id='5'>Diagnosis Type</th>";
	  A += "<th id='6'>Primary Ailment</th>";
	  A += "<th id='7' style='color='red';'>Hospitalization Type *</th>";
	  A += "<th id='8'>Treatment Plan *</th>";
	  A += "<th id='9'>Tariff Item</th>";
	  A += "<th id='10'>Delete</th>";		  
	  A += "</tr>";
	  A += "</thead>"; 		 	
	  for(var i=0;i<icdDtlArr.length;i++) {		 
		 var icdObj= icdDtlArr[i];				
		
		 A += "<tr id="+i+">";		 
	     A += "<td>"+icdObj.icdCodeDesc+"</td>";
	     A += "<td>"+"<a href='javascript:void(0)'; onclick='javascript:assoPcsDtls("+i+")'>"+icdObj.icdCodeLabel+"</td>";
	     A += "<td>"+"<a href='javascript:void(0)'; onclick='javascript:deAssPcsdtls("+i+")'>"+icdObj.icdPcsCode+"</td>";
	     A += "<td>"+icdObj.diagnosisName+"</td>";
	     A += "<td>"+icdObj.diagnosisType+"</td>";
	     A += "<td ALIGN='left'>";
	     A += "<div ALIGN='CENTER' class='form-check'>"; 
	     A += "<input class='form-check-input' onclick='javascript:priAilment("+this.value+","+i+")' value=''  name='group100' type='radio'  id='priAilment"+i+"'>";
	     A += "</div>";
	     A += "</td>";
	     A += "<td ALIGN='left'>";	     
	     A += "<select id='HspType"+i+"'>";       
	     A += "<option value=''>Select From List</option>";
	     A += "<option value='REL'>Regular</option>";
	     A += "<option value='REP'>Repeted</option>";    		           
	     A += "</select>";
	     A += "</td>";
	     A += "<td ALIGN='left'>";
	     A += "<select id='TreatP"+i+"'>";       
	     A += "<option value=''>Select From List</option>";
	     A += "<option value='SUR'>Surgical</option>";
	     A += "<option value='MED'>Medical</option>";    		           
	     A += "</select>";
	     A += "</td>";
	     A += "<td ALIGN='left'>";
	     A += "<select id='TarrifI"+i+"'>";       
	     A += "<option value='PKG'>Package</option>";
	     A += "<option value='NPK'>Non-Package</option>";		         		           
	     A += "</select>";
	     A += "</td>";
	     A += "<td>"+"<button id="+i+" onclick='javascript:delete_icd("+i+")' type='button'  class='btn vd-icon-btn' ><img src='"+contextpath+"/resources/vidal/images/vd_plus_btn.svg' alt='vd_plus_btn.''></button>"+"</td>";
	     A += "</tr>";	     
	 }
	     A += "</table>";
	     A += "</div>";
  
  document.getElementById('ICDData').innerHTML=A; 

}


function priAilment(browser , i) {
	for(var n = 0; n < icdDtlArr.length ; n++)
		{
			
		  document.getElementById("priAilment"+n).value = '';
		
		}
	browser = 'Y';
    document.getElementById("priAilment"+i).value = browser; 
    
}

/*Display  PCS  Details */
function displPcsDtla(){
	  
	  B = "<div class='vd-grid-style-basic'>";
	  B += "<table class='table table-basic' id='123'>";
	  B += "<thead>";
	  B += "<tr>";
	  B +=  "<th id='1'>PCS Code</th>";
	  B +=  "<th id='2'>Procedures Description</th>";		  
	  B +=  "<th id='3'>Delete</th>";
	  B += "</tr>";
	  B += "</thead>"; 
	  for(var i=0;i<pcsDtlArr.length;i++) {			 				
		var pcsObj= pcsDtlArr[i]; 
		 B += "<tr>";		 
	     B += "<td>"+pcsObj.pcsCodeLabel+"</td>";
	     B += "<td>"+pcsObj.pcsCodeDesc+"</td>";		     
	     B +="<td>"+"<button id="+i+" onclick='javascript:delete_pcs("+i+")'  type='button'  class='btn vd-icon-btn' ><img src='"+contextpath+"/resources/vidal/images/vd_plus_btn.svg' alt='vd_plus_btn.''></button>"+"</td>";
	     B += "</tr>";			     
	 }
	     B += "</table>";
	     B += "</div>";
	    	     
  document.getElementById('PCSData').innerHTML=B; // Display the elements of the array
}



/*Setting Pcs Related Details */
function setPcsDetails(varIndx,existPcsArr){
	
	var existPcsLengt=existPcsArr.length;
			
    for(var j=0;j<pcsDtlArr.length;j++) {	
    	existPcsArr[existPcsLengt]=pcsDtlArr[j];
    	existPcsLengt++;
    }
    var icdObj=getIndexedIcdObject(varIndx);
    icdObj["pcsDtls"]=existPcsArr;
}

/*Getting index length for ICD Objects */
function getIndexedIcdObject(varIndx){
for(var i=0;i<icdDtlArr.length;i++) {			 			
		if(varIndx==i){
		return icdDtlArr[i];
		}
}
}




function onSelectSubGroup(subGroupId) {
	
 	var subGroupid =subGroupId;
	    if(subGroupid == ''){
	     $("#medicineSystemSubTypeID")[0].options.length = 0;
	     $("#medicineSystemSubTypeID").prepend("<option value='' selected='selected'>Select From List</option>");
	    return false;
	    }else{	    	
	    var path=contextpath+"/doSubGroupList.htm?subGroupid="+subGroupid+""; 
	    
	    $.ajax({	    	
	        url :path,
	        success : function(data) { 	        	
	            var myselect1=document.getElementById("medicineSystemSubTypeID");
	      while (myselect1.hasChildNodes()) {   
	    	    myselect1.removeChild(myselect1.firstChild);
	        }    
	        // myselect1.options.add(new Option("City",""));
	          var res1 = data.split("#");	     
		     for(var i=0;i<res1.length-1;i++){	
		    	 var code=res1[i].split("@");	    
		        myselect1.options.add(new Option(code[1],code[0]));
		     }
		     var options = $("#medicineSystemSubTypeID option");                    // Collect options         
		     options.detach().sort(function(a,b) {               // Detach from select, then Sort
		         var at = $(a).text();
		         var bt = $(b).text();         
		         return (at > bt)?1:((at < bt)?-1:0);            // Tell the sort function how to order
		     });
		     options.appendTo("#medicineSystemSubTypeID");
		     $("#medicineSystemSubTypeID").prepend("<option value='' selected='selected'>Select From List</option>");		     
	        }
	    });
	    }
	}

/* this function is for Deleting  PCS Related Details  */
function delete_pcs(index_no){
	
	deletePcsSeqId(index_no);
	
	 var t1=pcsDtlArr.splice(index_no,1);	 
	 displPcsDtla(); // displaying the array elements
}


function deletePcsSeqId(index_no)
{
	
	var icsObj = new Object;
    icsObj=icdDtlArr[delPcsId];	
    
	var pcsCodes=document.getElementById('delpcsCodeSeqID').value;
	
	if(pcsCodes == undefined)
		{
		 
		  pcsCodes="";
		}
	else
		{
			
		  var pcsObj= pcsDtlArr[index_no];
		  
		  pcsCodes=pcsCodes+pcsObj.pcsCodeSeqID+",";
		  
		  document.getElementById('delpcsCodeSeqID').value = pcsCodes;	
		  
		  pcsObj.delpcsCodeSeqID = pcsCodes;
		 
		  icsObj.delpcsCodeSeqID=pcsCodes;
		  
		  icdDtlArr[delPcsId]=icsObj;
		
		}
		
}



function getCorrentPcdDtls(paramPcsDtlArr){
	var pcsCodes="";
	
	
	for(var i=0;i<paramPcsDtlArr.length;i++) {			 			
			
			var pcsObj= paramPcsDtlArr[i];
						
			pcsCodes=pcsCodes+pcsObj.pcsCodeLabel+",";
			
						
	 }
	return pcsCodes;
}

function getCorrentPcdSeqId(paramPcsDtlArr)
{
	var pcsSeqId="";
	for(var i=0;i<paramPcsDtlArr.length;i++) {			 			
		
		var pcsObj= paramPcsDtlArr[i];	
		if(pcsObj.pcsCodeSeqID != undefined)
			{
			  pcsSeqId=pcsSeqId+pcsObj.pcsCodeSeqID+",";
			}
		else
			{
			  pcsObj.pcsCodeSeqID = "";
			}		
		
      }
	
return pcsSeqId;
}



