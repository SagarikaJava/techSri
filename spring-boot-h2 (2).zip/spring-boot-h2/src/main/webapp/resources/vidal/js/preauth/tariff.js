
//Function on clicking calculate button

function onCalculate()
{
    trimForm(document.forms[1]);
    //calcReqAmt();
    //calcAppAmt();
    //calcMaxAmt();
    //calcAilAppAmt();
    document.forms[1].mode.value="doCalculate";
    document.forms[1].action = "/TariffSubmitAction.do";
    document.forms[1].submit();
}//end of onCalculate()


function checkDecimal()
{
    
    if(document.forms[1].wardTypeID !=null && document.forms[1].wardTypeID.length)//if more than one records are there
    {
    	var objwardTypeID=document.forms[1].elements['wardTypeID'];//added for maternity    	
    	var objDaysOfStay=document.forms[1].elements['daysOfStay'];
    	for(i=0;i<document.forms[1].wardTypeID.length;i++)
    	{
    	if(objwardTypeID[i].value=="ROO" || objwardTypeID[i].value=="ICU" || objwardTypeID[i].value=="ICN" || objwardTypeID[i].value=="NUC")
    	{
	var nbrofDays=objDaysOfStay[i].value;
	if(nbrofDays == 0 && nbrofDays != "")
	{
		alert("No. of Days should be a numeric value and multiples of 0.5");
		objDaysOfStay[i].select();
		return false;
	}
	else {
	var remder = nbrofDays - Math.floor(nbrofDays);
	if(remder <= 0.5)
		{
		if(remder != 0)
		{
		if(remder != 0.5)
			{
			alert("No. of Days should be a numeric value and multiples of 0.5");
			objDaysOfStay[i].select();
			return false;
			}
		}}
	else{
		alert("No. of Days should be a numeric value and multiples of 0.5");
		objDaysOfStay[i].select();
		return false;
	}
	}}
    }
    }
	}
//function on clicking save button
function onSave()
{

      trimForm(document.forms[1]);
      calcReqAmt();
      calcAppAmt();
      calcMaxAmt();
      calcAilAppAmt();
      if(!JS_SecondSubmit){
      	document.forms[1].mode.value="doSubmit";
      	document.forms[1].action ="TariffSubmitAction.do";
      	JS_SecondSubmit=true
      	document.forms[1].submit();
      }//end of if(!JS_SecondSubmit)	
}//end of onSave()

//function Reset


function showHideButton()
{
  document.getElementById("SV").style.display="none";
}//end of showHideButton

function calcReqAmt()
{
  var totReqAmt=0;
  regexp=/^([0])*\d{0,10}(\.\d{1,2})?$/;
  if(document.forms[1].selectedTariffSeqID !=null)
  {
    if(document.forms[1].selectedTariffSeqID.length)
    {
      var obj=document.forms[1].elements['tariffRequestedAmt'];
      for(i=0;i<obj.length;i++)
      {
        if(obj[i].value!="" && regexp.test(obj[i].value))
        totReqAmt= totReqAmt + parseFloat(obj[i].value);
      }//end of for
    }//end of if(document.forms[1].selectedTariffSeqID.length)
   }//end of  if(document.forms[1].selectedTariffSeqID !=null)
    if( document.forms[1].requestedPkgAmt.value!="" &&  regexp.test(document.forms[1].requestedPkgAmt.value))
    {
      totReqAmt=totReqAmt + parseFloat(document.forms[1].requestedPkgAmt.value);
	}//end of if( document.forms[1].requestedPkgAmt.value!="" &&  regexp.test(document.forms[1].requestedPkgAmt.value))
	document.forms[1].totReqAmt.value=totReqAmt;
    document.forms[1].totHidReqAmt.value=totReqAmt;
}//end of calcReqAmt()

function calcAppAmt()
{
  //alert("inside calc req amnt script");
  var totAppAmt=0;
  regexp=/^([0])*\d{0,10}(\.\d{1,2})?$/;
  if(document.forms[1].selectedTariffSeqID !=null)
  {
    if(document.forms[1].selectedTariffSeqID.length)
    {
      var obj=document.forms[1].elements['tariffApprovedAmt'];
      for(i=0;i<obj.length;i++)
      {
        if(obj[i].value!="" && regexp.test(obj[i].value))
        totAppAmt= totAppAmt + parseFloat(obj[i].value);
        //totAppAmt = Math.round(totAppAmt);
      }//end of for
    }//end of if(document.forms[1].selectedTariffSeqID.length)
   }//end of  if(document.forms[1].selectedTariffSeqID !=null)
    if( document.forms[1].approvedPkgAmt.value!="" &&  regexp.test(document.forms[1].approvedPkgAmt.value))
    {
      totAppAmt=totAppAmt + parseFloat(document.forms[1].approvedPkgAmt.value);
    }//end of if( document.forms[1].approvedPkgAmt.value!="" &&  regexp.test(document.forms[1].approvedPkgAmt.value))
   totAppAmt = Math.round(totAppAmt); 
   document.forms[1].totApprAmt.value=totAppAmt;
   document.forms[1].totHidApprAmt.value=totAppAmt;
}//end of calcAppAmt()

function calcMaxAmt()
{
  var totMaxAmt=0;
  regexp=/^([0])*\d{0,10}(\.\d{1,2})?$/;
  if(document.forms[1].selectedTariffSeqID !=null)
  {
    if(document.forms[1].selectedTariffSeqID.length)
    {
      var obj=document.forms[1].elements['tariffMaxAmtAllowed'];
      for(i=0;i<obj.length;i++)
      {
        if(obj[i].value!="" && regexp.test(obj[i].value))
        totMaxAmt= totMaxAmt + parseFloat(obj[i].value);
      }//end of for
    }//end of if(document.forms[1].selectedTariffSeqID.length)
   }//end of  if(document.forms[1].selectedTariffSeqID !=null)
   if( document.forms[1].maxPkgAmtAllowed.value!="" &&  regexp.test(document.forms[1].maxPkgAmtAllowed.value))
    {
      totMaxAmt=totMaxAmt + parseFloat(document.forms[1].maxPkgAmtAllowed.value);
    }//end of if( document.forms[1].maxPkgAmtAllowed.value!="" &&  regexp.test(document.forms[1].maxPkgAmtAllowed.value))
    document.forms[1].totMaxAmt.value=totMaxAmt;
    document.forms[1].totHidMaxAmt.value=totMaxAmt;
}//end of calcMaxAmt()

function calcAilAppAmt()
{
  var totAilAppAmt=0;
  regexp=/^([0])*\d{0,10}(\.\d{1,2})?$/;
  if(document.forms[1].selectedICDPCSSeqID !=null)
  {
    if(document.forms[1].selectedICDPCSSeqID.length >= 0)
    {
      var obj=document.forms[1].elements['approvedAilmentAmt'];
      for(i=0;i<obj.length;i++)
      {
        if(obj[i].value!="" && regexp.test(obj[i].value))
        totAilAppAmt= totAilAppAmt + parseFloat(obj[i].value);
        //alert("inside loop :"+totAilAppAmt);
      }//end of for
    }//end of if(document.forms[1].selectedICDPCSSeqID.length >= 0)
    else
    {
      var obj=document.forms[1].elements['approvedAilmentAmt'];

      if(obj.value!="" && regexp.test(obj.value))
      totAilAppAmt= totAilAppAmt + parseFloat(obj.value);
    }//end of else
  }//end of if(document.forms[1].selectedICDPCSSeqID !=null)
    document.forms[1].totHidAilAppAmt.value=totAilAppAmt;
}//end of calcAilAppAmt()

//Tariff_tips_integration
function calNetAmt()
{  
	var totAppAmt=0;
	regexp=/^([0])*\d{0,10}(\.\d{1,2})?$/;
	var obj=document.forms[1].elements['applyDiscountYN'];
	var obj1=document.forms[1].elements['tariffApprovedAmt'];//tariffApprovedAmt claimNetAmount
	var obj2=document.forms[1].elements['tariffRequestedAmt'];//tariffRequestedAmt claimBillAmt
	var obj3=document.forms[1].elements['discountPercent'];
	var obj4=document.forms[1].elements['hideDiscountYN'];
	var obj5=document.forms[1].elements['tariffMaxAmtAllowed'];//tariffMaxAmtAllowed claimMaxAmount
	/*alert("applyDiscountYN:"+document.getElementById("applyDiscountYN").value);
	alert("tariffApprovedAmt:"+document.getElementById("tariffApprovedAmt").value);
	alert("tariffRequestedAmt:"+document.getElementById("tariffRequestedAmt").value);
	alert("discountPercent:"+document.getElementById("discountPercent").value);
	alert("hideDiscountYN:"+document.getElementById("hideDiscountYN").value);
	alert("tariffMaxAmtAllowed:"+document.getElementById("tariffMaxAmtAllowed").value);
	alert("selectedWardAccGroupSeqID:"+document.forms[1].selectedWardAccGroupSeqID.length);*/
	if(document.forms[1].selectedWardAccGroupSeqID.length)
	{			
		for(i=0,j=0;i<obj.length;i++)
		{			
			if(obj2[i].value=="")
				obj2[i].value="0.00";
		    else
	          	obj2[i].value=parseFloat(obj2[i].value).toFixed(2);
			if(obj5[i].value=="")
				obj5[i].value="0.00";
		    else
	          	obj5[i].value=parseFloat(obj5[i].value).toFixed(2);
			if(!(obj[i].checked))
            {
				obj1[i].value=parseFloat(obj2[i].value).toFixed(2);								
				obj4[i].value='N';				
            }//end of if(!(obj[i].checked))

            if((obj[i].checked))
            {
            	obj1[i].value= parseFloat(((obj2[i].value))-((obj2[i].value)*(obj3[i].value))/100).toFixed(2);            	
            	obj4[i].value='Y';            	
            }//end of if((obj[j].checked))
       }//end of for(i=0;i<obj.length;i++)
    }//end of if(document.forms[1].selectedWardAccGroupSeqID.length)
    else
    {    	
    	if(obj2.value=="")
			obj2.value="0.00";
	    else
          	obj2.value=parseFloat(obj2.value).toFixed(2);
    	if(obj5.value=="")
			obj5.value="0.00";
	    else
          	obj5.value=parseFloat(obj5.value).toFixed(2);
    	if(!(obj.checked))
        {
    		obj1.value=parseFloat(obj2.value).toFixed(2);    		
            obj4.value='N';            
        }//end of if(!(obj.checked))

        if((obj.checked))
        {
        	obj1.value= parseFloat(((obj2.value))-((obj2.value)*(obj3.value))/100).toFixed(2);        	
            obj4.value='Y';
        }//end of if((obj.checked))
    }
	calcTotalApprAmt();//calTotNet();
}//end of function calNetAmt()//Maternity_limit_restriction
//s
function calProDistAmt()
{
	var totAppAmt=0;
	regexp=/^([0])*\d{0,10}(\.\d{1,2})?$/;
	var obj=document.forms[1].elements['finalProApplyDiscountYN']; //applyDiscountYN
	var obj1=document.forms[1].elements['finalProDiscountedPackageAmt']; //claimNetAmount
	var obj2=document.forms[1].elements['proDiscountedPackageAmt']; //claimBillAmt
	var obj3=document.forms[1].elements['finalProPkgDiscountPercentage']; //discountPercent
	var obj4=document.forms[1].elements['prohideDiscountYN']; //hideDiscountYN
	
	if(document.forms[1].length)
	{			
		for(i=0,j=0;i<obj.length;i++)
		{			
			if(obj2[i].value=="")
				obj2[i].value="0.00";
		    else
	          	obj2[i].value=parseFloat(obj2[i].value).toFixed(2);			
			if(!(obj[i].checked))
            {
				obj1[i].value=parseFloat(obj2[i].value).toFixed(2);								
				obj4[i].value='N';				
            }//end of if(!(obj[i].checked))

            if((obj[i].checked))
            { 
            	//if(obj3[i].value != 100)
            	{
            	obj1[i].value= parseFloat(((obj2[i].value))-((obj2[i].value)*(obj3[i].value))/100).toFixed(2);            	
            	obj4[i].value='Y';
            	}
            	/*else
            	{
            		obj1[i].value= parseFloat(obj2[i].value);
            		obj4[i].value='Y';
            	}*/
            }//end of if((obj[j].checked))
       }//end of for(i=0;i<obj.length;i++)
    }//end of if(document.forms[1].selectedWardAccGroupSeqID.length)
    else
    {    	
    	if(obj2.value=="")
			obj2.value="0.00";
	    else
          	obj2.value=parseFloat(obj2.value).toFixed(2);
    	
    	if(!(obj.checked))
        {
    		obj1.value=parseFloat(obj2.value).toFixed(2);    		
            obj4.value='N';            
        }//end of if(!(obj.checked))

        if((obj.checked))
        { 
        	//if(obj3[i].value != 100)
        	{
        	obj1.value= parseFloat(((obj2.value))-((obj2.value)*(obj3.value))/100).toFixed(2);        	
            obj4.value='Y';
        	}
        	/*else
        	{
        		obj1[i].value= parseFloat(obj2[i].value);
        		obj4[i].value='Y';
        	}*/
        }//end of if((obj.checked))
    }
		
}
function calDistProAmt()
{
	var totAppAmt=0;
	regexp=/^([0])*\d{0,10}(\.\d{1,2})?$/;
	var obj=document.forms[1].elements['ailApplyDiscountYN']; //applyDiscountYN
	var obj1=document.forms[1].elements['ailDiscountedPackageAmt']; //claimNetAmount
	var obj2=document.forms[1].elements['discountedPackageAmt']; //claimBillAmt
	var obj3=document.forms[1].elements['ailPkgDiscountPercentage']; //discountPercent
	var obj4=document.forms[1].elements['alihideDiscountYN']; //hideDiscountYN
	
	if(document.forms[1].length)
	{			
		for(i=0,j=0;i<obj.length;i++)
		{			
			if(obj2[i].value=="")
				obj2[i].value="0.00";
		    else
	          	obj2[i].value=parseFloat(obj2[i].value).toFixed(2);			
			if(!(obj[i].checked))
            {
				obj1[i].value=parseFloat(obj2[i].value).toFixed(2);								
				obj4[i].value='N';				
            }//end of if(!(obj[i].checked))

            if((obj[i].checked))
            { 
            	//if(obj3[i].value != 100)
            	{
            	obj1[i].value= parseFloat(((obj2[i].value))-((obj2[i].value)*(obj3[i].value))/100).toFixed(2);            	
            	obj4[i].value='Y';
            	}
            	/*else
            	{
            		obj1[i].value= parseFloat(obj2[i].value);
            		obj4[i].value='Y';
            	}*/
            }//end of if((obj[j].checked))
       }//end of for(i=0;i<obj.length;i++)
    }//end of if(document.forms[1].selectedWardAccGroupSeqID.length)
    else
    {    	
    	if(obj2.value=="")
			obj2.value="0.00";
	    else
          	obj2.value=parseFloat(obj2.value).toFixed(2);
    	
    	if(!(obj.checked))
        {
    		obj1.value=parseFloat(obj2.value).toFixed(2);    		
            obj4.value='N';            
        }//end of if(!(obj.checked))

        if((obj.checked))
        { 
        	//if(obj3[i].value != 100)
        	{
        	obj1.value= parseFloat(((obj2.value))-((obj2.value)*(obj3.value))/100).toFixed(2);        	
            obj4.value='Y';
        	}
        	/*else
        	{
        		obj1[i].value= parseFloat(obj2[i].value);
        		obj4[i].value='Y';
        	}*/
        }//end of if((obj.checked))
    }
	
}
//e

function onPdfView()
{
	   document.forms[1].child.value="";
	   document.forms[1].mode.value="doPdfView";
	   document.forms[1].action="/PreAuthTariffAction.do";
	   document.forms[1].submit();
}//end of onPdfView()

//Maternity_limit_restriction
function onRuleDetailView(){
	var action="/PreAuthTariffRuleDataAction.do?mode=doRuleDetailView"; //doRuleDetail
	window.open(action,"_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=800,left=800,width=500,height=500");
}