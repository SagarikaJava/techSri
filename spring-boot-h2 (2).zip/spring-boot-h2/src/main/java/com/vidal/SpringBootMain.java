package com.vidal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.websocket.Endpoint;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;


@SpringBootApplication(scanBasePackages={"com.vidal", "com.vidal.validation","dao","formbean","model"})
//@EntityScan(value={"com.vidal.Register","com.vidal.User"})
//@EntityScan("com.vidal")
public class SpringBootMain{

	//Logger log = Logger.getLogger(SpringBootMain.class);
	
//	@Autowired
//	StudentRepository repository;
	
	public static void main(String[] args)
	{
		SpringApplication.run(SpringBootMain.class, args);
	}
	
	public void run(String... args) throws Exception {
		/*log.info("list of students :: "+repository.findAll());
		log.info("student save ::: "+repository.save(new Student("SHAIL", "d781234")));
		log.info("student save with id :: "+repository.save(new Student(103L, "BINA", "C34251672")));
		log.info("update student with id 101 :: "+repository.save(new Student(101L, "SATYA", "S9089213")));*/
	}

	
	
	  
}
