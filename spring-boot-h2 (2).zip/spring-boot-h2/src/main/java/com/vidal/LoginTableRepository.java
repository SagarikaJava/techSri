package com.vidal;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginTableRepository extends JpaRepository<LoginTable, Long>{

	@Query("select userid,password,email,phone  from LoginTable where email = ?")
	List<LoginTable> getDataByEmail(String email);
}
