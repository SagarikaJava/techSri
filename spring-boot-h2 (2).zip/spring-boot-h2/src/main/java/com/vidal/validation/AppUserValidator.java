/*package com.vidal.validation;

import model.AppUser;

import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import dao.*;
import formbean.AppUserFormBean;

@Component
public class AppUserValidator implements Validator{

	@Autowired
	private AppUserDAO appUserDAO;
	
	private EmailValidator emailValidator = EmailValidator.getInstance();

	public boolean supports(Class<?> clazz) {
		return clazz==AppUserFormBean.class;
	}

	public void validate(Object target, Errors errors) {
		
		AppUserFormBean appUserFormBean = (AppUserFormBean) target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "NotEmpty.appUserFormBean.userName");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "NotEmpty.appUserFormBean.firstName");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "NotEmpty.appUserFormBean.lastName");
	    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "NotEmpty.appUserFormBean.email");
	    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.appUserFormBean.password");
	    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword", "NotEmpty.appUserFormBean.confirmPassword");
	    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gender", "NotEmpty.appUserFormBean.gender");
	    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "countryCode", "NotEmpty.appUserFormBean.countryCode");
	    
	    if(!this.emailValidator.isValid(appUserFormBean.getEmail()))
	    {
	    	errors.rejectValue("email", "Pattern.appUserFormBean.email");
	    }
	    else if(appUserFormBean.getUserId()==null)
	    {
	    	AppUser dbUser = appUserDAO.findAppUserByEmail(appUserFormBean.getEmail());
	    	if(dbUser!=null)
	    	{
	    		errors.rejectValue("email", "Duplicate.appUserFormBean.email");
	    	}
	    }
	    if(!errors.hasFieldErrors("userName"))
	    {
	    	AppUser dbUser = appUserDAO.findAppUserByName(appUserFormBean.getUserName());
	    	if(dbUser!=null)
	    	{
	    		errors.rejectValue("userName", "Duplicate.appUserFormBean.userName");
	    	}
	    }
	    if(!errors.hasErrors())
	    {
	    	if(!appUserFormBean.getConfirmPassword().equals(appUserFormBean.getPassword()))
	    	{
	    		errors.rejectValue("confirmPassword", "Match.appUserFormBean.confirmPassword");
	    	}
	    }
	}
}
*/