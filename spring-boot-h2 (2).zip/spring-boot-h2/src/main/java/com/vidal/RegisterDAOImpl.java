package com.vidal;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
public class RegisterDAOImpl{

	public List<Register> getUserName(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Register> getValidLogin(String email, String password) {
	//String query = "select case when count(*)>=1 then 'Y' else 'Invalid Login.' end from user1 where email=:email and password=:password";
	//System.out.println(query);
	Register reg = new Register();
	reg.setEmail("sagarika.das@gmail.com");
	reg.setPassword("Vidal@123");
	List list = new ArrayList();
	list.add(reg);

	return list;
	}

	public List<Register> getDataByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public int addNewUser(double userid, String name, String email, String phone, String password) {
		System.out.println("Inside addnewuser dao");
	    String save_query = "insert into register(user_id,name,email,phone,password) values (:userid,:name,:email,:phone,:password)";
		SqlParameterSource params = new MapSqlParameterSource()
				.addValue("user_id", userid)
				.addValue("name", name)
				.addValue("email", email)
				.addValue("phone", phone)
				.addValue("password", password);
		int result = jdbcTemplate.update(save_query, params);
		
		return result;
	}
	
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;
}
