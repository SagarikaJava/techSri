package com.vidal;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



@RestController
public class SpringBootJdbcController {
	
	@Autowired
	SPService service;
	@Autowired
	StudentRepository studentRepository;
	@Autowired
	RegisterRepository registerRepository;
	@Autowired
	LoginTableRepository LoginTableRepository;
	
	private static Logger log = Logger.getLogger( SpringBootJdbcController.class );
	
//--------------------------------------------------------------------------------------------------------------------------------------	
	@RequestMapping(value="/")
	public ModelAndView normal(@ModelAttribute("user") User user,HttpServletRequest request)
	
	{
		System.out.println("inside index() controller");
		ModelAndView mav = new ModelAndView();
		mav.addObject("login", "LOGIN");//set request attribute name(coming in jsp)
		HttpSession session = request.getSession();
		session.setAttribute("login2", "LOGIN2");//request attribute null
		request.getSession().setAttribute("login3","LOGIN3");//request attribute null
		mav.setViewName("boot_login");
		return mav;
	}
//--------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping(value="/afterlogin")
	public ModelAndView afterLogin(@ModelAttribute("student") Student student,HttpServletRequest request) 
	{
		/*if(bindingResult.hasErrors())return new ModelAndView("studentlogin");*/
		System.out.println("inside afterLogin() controller");
		ModelAndView mav = new ModelAndView();
		log.info("email :"+student.getEmail()+"password : "+student.getPassword());
		//List<Student> name = studentRepository.getStudentName(student.getEmail(), student.getPassword());
		List validLogin = studentRepository.getValidLogin(student.getEmail(), student.getPassword());
		String result = validLogin.get(0).toString();
		log.info("name in afterlogin student :: "+result);
		
		if(result.equals("Invalid Login."))
		{
			mav.setViewName("errorpage");
			request.setAttribute("message", "Invalid Login. Enter valid Email and Password !");
		}
		else
		{
			mav.setViewName("successlogin");
		}
		return mav;
	}
//--------------------------------------------------------------------------------------------------------------------------------------	
	@RequestMapping(value = "/login")
	public ModelAndView login(@Valid @ModelAttribute("user") User user,BindingResult bindingResult,HttpServletRequest req) {
		if(bindingResult.hasErrors())return new ModelAndView("boot_login");
		ModelAndView mav = new ModelAndView();
		System.out.println("inside login() controller emailid and password ");
		System.out.println("name : "+user.getEmail()+" password : "+user.getPassword());
		//call dao procedure for validation
		List result = registerRepository.getValidLogin(user.getEmail(), user.getPassword());
		log.info("result in action :"+result.get(0));
		String result1 = result.get(0).toString();
		System.out.println("result1 :"+result1);
		if(!result1.equals("1"))
		{
			mav.setViewName("errorpage");
			req.setAttribute("message", "Invalid username / password . Please try again ! ");
		}
		else
		{
			req.setAttribute("name", result);
			mav.setViewName("successlogin");
		}
		return mav;
	}//login
//--------------------------------------------------------------------------------------------------------------------------------------	
	@RequestMapping("/getEmp")
	public ModelAndView getEmp(@ModelAttribute("register") Register register){
		log.info("inside getEmp controller()");
		log.info("email jsp: "+register.getEmail());
		ModelAndView mav = new ModelAndView();
		mav.setViewName("boot_empData");
		return mav;
	}
//--------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping("/empdata")
	public ModelAndView getEmpById(@ModelAttribute("register") Register register,HttpServletRequest request) throws SQLException
	{
		log.info("inside enteremail controller....");
		//do db operation
		log.info("email in getEmpById() : "+register.getEmail());
		List result = registerRepository.getDataByEmail(register.getEmail());
		//ArrayList<Register> al = new ArrayList<Register>();
		//al.add(register);
		ModelAndView mav = new ModelAndView();
		mav.addObject("al", result);
		mav.setViewName("boot_emailidData");
		return mav;
	}
//--------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping("/dashboard")
	public ModelAndView dashboard()
	{
		ModelAndView mav = new ModelAndView();
		mav.setViewName("dashboard");
		return mav;
	}
//--------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping(value="/back")
	public ModelAndView back()
	{
		System.out.println("inside back() ::");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
//--------------------------------------------------------------------------------------------------------------------------------------	
	@RequestMapping(value = "/forgotpwdd")
	public ModelAndView forgotpwd() {
		System.out.println("inside forgotpwd() controller");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("forgotpassword");
		return mav;
	}//forgotpwd
//--------------------------------------------------------------------------------------------------------------------------------------	
	@RequestMapping(value = "/forgotpwdchange", method = RequestMethod.GET)
	public ModelAndView forgotpwdchange() {
		System.out.println("inside forgotpwdchange() controller");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("forgotpwdchange");
		return mav;
	}//forgotpwdchange
//--------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping(value = "/register")
	public ModelAndView register(@ModelAttribute("register") Register register,BindingResult bindingResult) {
		log.info("inside register() controller");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("boot_register");
		return mav;
	}
//--------------------------------------------------------------------------------------------------------------------------------------	
	
	//while call the register button then on click of submit this method calls
	//read all input data call dao method
	@RequestMapping(value = "/submitregister")
	public ModelAndView submitregister(@Valid @ModelAttribute("register") Register register, BindingResult result,Model model,HttpServletRequest request) throws SQLException {
		ModelAndView mav = new ModelAndView();
		if(result.hasErrors())return new ModelAndView("boot_register");
		log.info("inside submitregister() controller");
		//String name = request.getParameter("userid");
		log.info("name :: "+register.getName()+" user id : "+register.getUserid()+"email id : "+register.getEmail()+"phone no : "+register.getPhone()+"password : "+register.getPassword());
		double userid = Math.random();
		int count = registerRepository.addNewUser(userid,register.getName(),register.getEmail(),register.getPhone(),register.getPassword());
		
		System.out.println("count :: "+count);
		System.out.println("register :"+register.toString()+"name :"+register.getName());
		if(count>0){
		request.getSession().setAttribute("name", register.getName());
		mav.setViewName("successregister");
		}
		return mav;
	}//successregister
//--------------------------------------------------------------------------------------------------------------------------------------	
	
	@RequestMapping(value = "/add-cust1", method = RequestMethod.GET)
	public ModelAndView msg() {
		System.out.println("inside add-cust()1 controller");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("userdadded");
		// return "redirect:/userdadded";
		return mav;
	}
//--------------------------------------------------------------------------------------------------------------------------------------
/*	//for db connectivity fine
	@RequestMapping(value="/add-cust",method=RequestMethod.POST)
	public ModelAndView save(@ModelAttribute Customer customer)
	{
		System.out.println("inside add-cust() controller");
		service.addUser(customer);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("customer", customer);
		mav.setViewName("userdadded");
		return mav;
	}*/
//--------------------------------------------------------------------------------------------------------------------------------------
	/*@RequestMapping(value="/update",method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute Customer customer)
	{
		ModelAndView mav = new ModelAndView();
		mav.setViewName("update");//need to create jsp
		mav.addObject("customer", customer);
		return mav;
	}
	*/
//--------------------------------------------------------------------------------------------------------------------------------------
/*	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public ModelAndView delete(@ModelAttribute Customer customer)
	{
		ModelAndView mav = new ModelAndView();
		mav.setViewName("delete");//need to create jsp
		mav.addObject("customer", customer);
		return mav;
	}*/
//----------------------------------------------------------------------------------------------------------------------------------
    // getting xml as output
/*	@RestController
    public class PersonController {
		
        @Autowired
        private SPRepository repository;
        
        @RequestMapping(value = "/persons/{id}", method = RequestMethod.GET,produces={MediaType.APPLICATION_XML_VALUE},headers = "Accept=application/xml")
        public ResponseEntity<?> getPersonDetails(@PathVariable Long id, final HttpServletRequest request)throws Exception {
            Person personResponse=repository.findPersonById(id);
            ResponseEntity<Person> response = ResponseEntity.ok(personResponse);
            System.out.println("response :: "+response);
            return ResponseEntity.ok(personResponse);
        }

    }*/
//----------------------------------------------------------------------------------------------------------------------------------
/*	//posting xml as body
	@RestController
	public class XmlController{
		@PostMapping(path="/save-cust-info")
		public String postxml(@RequestBody Person person)
		{
			System.out.println("inside savecust method");
			return "cust name :"+person.getFirst_name()+"  id :"+person.getId();
		}
	}
	*/
	
//-----------------------------------------------------------

/*@RequestMapping("/test")
     public ModelAndView test(@ModelAttribute("employeeEntity") EmployeeEntity employeeEntity,Model model){
         System.out.println("aaaaaaaa");
         ModelAndView andView = new ModelAndView("test");
         model.addAttribute(employeeEntity);
         return andView;
     } 
    @RequestMapping("/insert")
    public ModelAndView index(@ModelAttribute("employeeEntity") EmployeeEntity employeeEntity,HttpServletRequest request) throws SQLException{
        System.out.println("inside index");
        System.out.println("qqqqqqqqqqq polSeq "+employeeEntity.getPolSeq()+"polgrp seq:"+employeeEntity.getPolGrpSeq());
        return null;
    } */
	
	
}
