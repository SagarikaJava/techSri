package com.vidal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="REGISTER_ONE")
public class Register {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private double userid;
	@NotEmpty(message="Please enter emailid")
	@Email(message="Please enter valid emailid")
	private String email;
	@NotEmpty(message="Please enter name")
	private String name;
	@NotEmpty(message="Please enter passowrd")
	private String password;
	@NotEmpty(message="Please enter mobileno")
	@Size(min=10,max=10,message="Please enter 10 digit mobile number")
	private String phone;
	
	
	public Register() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getUserid() {
		return userid;
	}
	public void setUserid(double userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

}
