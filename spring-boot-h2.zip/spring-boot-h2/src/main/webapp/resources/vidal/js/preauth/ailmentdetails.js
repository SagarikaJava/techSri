$(function () {
          $("#ddlPassport").change(function () {
              if ($(this).val() == "MAS") {
                  $("#dvPassport").show();
              } else {
                  $("#dvPassport").hide();
              }
              if ($(this).val() == "IntNat") {
                  $("#dvPassport2").show();
              } else {
                  $("#dvPassport2").hide();
              }
          });
      });

function showHideType()
{
	
	var specialityTypeID= document.forms[1].specialityTypeID.value;
	
		 if(specialityTypeID=='SUR')
	    {
	    	 document.getElementById("surgerytype").style.display="";
	    	 
	    }//end of if(specialityTypeID=='SUR')
	    else
	    {
	    	document.getElementById("surgerytype").style.display="none";
	    }//end of else	
	if(specialityTypeID=='MAS')
	 {
		 
		 document.getElementById("maternitytype").style.display="";
	     document.getElementById("lmpdate").style.display="";
		 document.getElementById("noofchildren").style.display="";
		 //added for maternity new
		 document.getElementById("noofbiological").style.display="";
		 document.getElementById("noofadopted").style.display="";
		 document.getElementById("deliveriesNo").style.display="";
		 //added for maternity new
	 }//end of if(specialityTypeID=='MAS')
	else
	 {
		 document.forms[1].elements['maternityTypeID'].value = "";
		 document.forms[1].elements['livingChildrenNumber'].value = "";
		 document.forms[1].elements['lmpDate'].value = "";
		 document.forms[1].elements['childDate'].value = "";
		 document.forms[1].elements['vaccineDate'].value = "";
		 document.getElementById("maternitytype").style.display="none";
	     document.getElementById("lmpdate").style.display="none";
	     document.getElementById("noofchildren").style.display="none";
	     //added for maternity new
	     document.getElementById("noofbiological").style.display="none";
		 document.getElementById("noofadopted").style.display="none";
		 document.getElementById("deliveriesNo").style.display="none";
		 //added for maternity new
	     document.getElementById("childDob").style.display="none";
	     document.getElementById("vaccineDob").style.display="none";
	     
	 }//end of else
}//end of showHideType()