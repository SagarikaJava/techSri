$(document).ready(function(){
	//alert("hello"+ document.getElementById("flagId").value);
	
	openUserAssignment(); 
    $("#uploadid").click(function(){
       if(document.forms['frmManualUploadId'].sentForm.value == ""){
    	   swal("Please enter From Mail Id.");
    	   return false;
       }
       if(document.forms['frmManualUploadId'].sentDate.value == ""){
    	   swal("Please enter Mail Received Date.");
    	   return false;
       }
       $("#frmManualUploadId").attr('action',contextpath+"/medical/ManualUpload").submit();
    });
    
    $('.c_close').click(function () {
       $(this).parents('div.cpopBox').fadeOut();
    });
    
   /* document.getElementById("uploadBtn").onchange = function () {
   	document.getElementById("test123").innerHTML="<H5><i class='fa fa-spinner fa-pulse fa-2x fa-fw'></i> Uploading...</H5>";
   	$("#frmUpload").attr('action',contextpath+"/Pre-Authorization/ManualUpload").submit();
    };*/
   
    $("#refID").click(function(){
        $("#frmUpload").attr('action',contextpath+"/medical/Dashboard").submit();
    });
    
	function reFresh(){
		alert("Hi");
		setInterval("reFresh()",1000);
	}
	
	function openUserAssignment(){
		if(document.getElementById("flagId").value != ""){
			$('body').addClass('sidebar');
		    $("#advance_search").show("slide", {
		        direction: "right"
		    }, 500);
		    $("#vd-overlay").addClass("vd-overlay-side-panel").fadeIn("slow");
		}
	}
});

//document.forms[1].tableNameId.value=str;
//$('#tableNameId').val(str);
//	document.getElementById('tableNameId').value = str;
//	document.getElementById('child').value = "joker";
//document.forms[1].child.value=str;
//	alert(document.getElementById('tableNameId').value);

/*
 	onUserAssignmentTest(rownum){
 		$('body').addClass('sidebar');
		    //var getId = $(this).attr('data-open');
		    $("#advance_search").show("slide", {
		        direction: "right"
		    }, 500);
		    $("#vd-overlay").addClass("vd-overlay-side-panel").fadeIn("slow");
 	}
 */
function toggle(sortid,str)
{
	$('#childId').val(str);
    $('#sortId').val(sortid);
    $('#frmSub').attr('action',contextpath+"/medical/Dashboard").submit();
}//end of toggle(sortid)

function pageIndex(pagenumber,str){
	$('#childId').val(str);
    $('#pageId').val(pagenumber);
	$('#frmSub').attr('action',contextpath+"/medical/Dashboard").submit();
}

//function to display next set of pages
function PressForward(str)
{ 
	$('#childId').val(str);
    $('#frmSub').attr('action',contextpath+"/medical/dashboard/forward").submit();
}//end of PressForward()

//function to display previous set of pages
function PressBackWard(str)
{ 
	$('#childId').val(str);
	$('#frmSub').attr('action',contextpath+"/medical/dashboard/backward").submit();
}//end of PressBackWard()
function gggggggonUserIcon(rownum)
{
	document.forms[1].mode.value="doAssign";
	document.forms[1].child.value="Assign";
	document.forms[1].rownum.value=rownum;
	document.forms[1].action="/AssignToAction.do";
	document.forms[1].submit();
}//end of onUserIcon(rownum)
function onUserAssignment(num){
	$('#assignusernoId').val(num);
	$('#frmAssign').attr('action',contextpath+"/medical/assignuser").submit();
}
function edit(rownum,str){
	$('#childId').val(str);
    $('#rownumId').val(rownum);
	$('#frmSub').attr('action',contextpath+"/medical/edit").submit();
}
function queueStatus(str){
	$('#queueId').val(str);
	$('#frmSub').attr('action',contextpath+"/medical/Dashboard").submit();
}
function quickSearch(str){
	$('#quicksearchId').val(str);
	$('#frmUpload').attr('action',contextpath+"/medical/Dashboard").submit();
}