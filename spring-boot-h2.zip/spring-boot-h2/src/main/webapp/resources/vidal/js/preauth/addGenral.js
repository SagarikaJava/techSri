
function savePreAuth()
{ 	   	  
	   $('.generalDisable').removeAttr("disabled");
	document.forms["genForm"].action = contextpath+"/preauth/addPreAuth";
	document.forms["genForm"].submit();
}   





function onEnrollSearch()
{ 
	
	InsurerName=document.forms["genForm"].InsurerName.value;
	enEnrollmentId=document.forms["genForm"].enEnrollmentId.value;
	enInsuranceSeqID=document.forms["genForm"].enInsuranceSeqID.value;
	enSchemaName=document.forms["genForm"].enSchemaName.value;
	enCertificateNumber=document.forms["genForm"].enCertificateNumber.value;
	engender=document.forms["genForm"].engender.value;
	enPolicyNumber=document.forms["genForm"].enPolicyNumber.value;
	enEmployeeNumber=document.forms["genForm"].enEmployeeNumber.value;
	enCorporateName=document.forms["genForm"].enCorporateName.value;
/*	enshowLatest=document.forms["genForm"].enshowLatest.value;*/
	  if($('#checkbox1').is(':checked')){
		  enshowLatest = "Y";
      }else{
    	  enshowLatest = "";
      }
     
	
	if(((InsurerName==="")&&(enEnrollmentId==="")&&(enSchemaName==="")&&(enCertificateNumber==="")&&(engender==="")&&(enPolicyNumber==="")
			&&(enInsuranceSeqID==="")&&(enEmployeeNumber==="")&&(enCorporateName==="") )){
		
		swal("Please provide any one search criteria.");
	return false;
	}
	document.getElementById("enrolserach").innerHTML ="Please Wait...";
	var parameters="InsurerName="+InsurerName+"&"+"enEnrollmentId="+enEnrollmentId+"&"+"enInsuranceSeqID="+enInsuranceSeqID+"&"+"enSchemaName="+enSchemaName+"&"+"enCertificateNumber="+enCertificateNumber+"&"+"engender="+engender+"&"+"enPolicyNumber="+enPolicyNumber+"&"+"enEmployeeNumber="+enEmployeeNumber+"&"+"enCorporateName="+enCorporateName+"&"+"enshowLatest="+enshowLatest;

	var xhttpObj=null;
	if(xhttpObj==null){	
		if (window.XMLHttpRequest) {
			// code for modern browsers
			xhttpObj = new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	//document.getElementById("enrollementTableGrid").innerHTML ="PLease WAIT   ........";
	/*document.getElementById("enrolserach").innerHTML ="Please Wait...";*/
	
	
	if(sessionStorage.getItem("pageIndexsearch")==="pageindex"){
		xhttpObj.open("GET",contextpath+"/preauth/doSearchEnrollment?"+parameters+"&pageId="+sessionStorage.getItem("pageId"), false);
	}else if(sessionStorage.getItem("pageIndexsearch")==="toggle"){
		xhttpObj.open("GET",contextpath+"/preauth/doSearchEnrollment?"+parameters+"&sortId="+sessionStorage.getItem("sortId"), false);
	}
	else{
		xhttpObj.open("GET",contextpath+"/preauth/doSearchEnrollment?"+parameters, false);

	}
	
	
	xhttpObj.send();
	var sData=xhttpObj.responseText;
	
	if(sData!==null&&sData!==""&&sData.length>1){

		document.getElementById("enrollementTableGrid").innerHTML =sData;
		document.getElementById("enrolserach").innerHTML ="Search";
		
	}else{

		document.getElementById("enrollementTableGrid").innerHTML ="";

	}
	sessionStorage.setItem("pageIndexsearch","");
	sessionStorage.setItem("pageId","");
	sessionStorage.setItem("sortId","");

}//end of  function onEnrollSearch()

function onSearchPolicy()
{		
	var parameters="polInsurenceCompany="+document.forms["genForm"].polInsurenceCompany.value+"&"+
	"polPolicyNo="+document.forms["genForm"].polPolicyNo.value+"&"+
	"polCorparateName="+document.forms["genForm"].polCorparateName.value;

	var xhttpObj=null;
	if(xhttpObj==null){	
		if (window.XMLHttpRequest) {
			// code for modern browsers
			xhttpObj = new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	document.getElementById("policyTableGrid").innerHTML ="";
	if(sessionStorage.getItem("pageIndexsearch")==="pageindex"){
		xhttpObj.open("GET",contextpath+"/preauth/doSearchPolicy?"+parameters+"&pageId="+sessionStorage.getItem("pageId"), false);
	}else if(sessionStorage.getItem("pageIndexsearch")==="toggle"){
		xhttpObj.open("GET",contextpath+"/preauth/doSearchPolicy?"+parameters+"&sortId="+sessionStorage.getItem("sortId"), false);
	}

	else{
		xhttpObj.open("GET",contextpath+"/preauth/doSearchPolicy?"+parameters, false);

	}
	xhttpObj.send();
	
	
	var sData=xhttpObj.responseText;
	if(sData!==null&&sData!==""&&sData.length>1){

		document.getElementById("policyTableGrid").innerHTML =sData;
	}else{
		document.getElementById("policyTableGrid").innerHTML ="";
	}
	sessionStorage.setItem("pageIndexsearch","");
	sessionStorage.setItem("pageId","");
	sessionStorage.setItem("sortId","");

}//end of onSearchPolicy





function onSearchInsCom()
{		

	var parameters="InsurenceCompany="+document.forms["genForm"].InsurenceCompany.value+"&"+
	"CompanyName="+document.forms["genForm"].companyName.value+"&"+
	"VidalBranch1="+document.forms["genForm"].VidalBranch1.value;

	var xhttpObj=null;
	if(xhttpObj==null){	
		if (window.XMLHttpRequest) {
			// code for modern browsers
			xhttpObj = new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	document.getElementById("inscompTableGrid").innerHTML ="";

	if(sessionStorage.getItem("pageIndexsearch")==="pageindex"){
		xhttpObj.open("GET",contextpath+"/preauth/doSearchInsComp?"+parameters+"&pageId="+sessionStorage.getItem("pageId"), false);
	}else if(sessionStorage.getItem("pageIndexsearch")==="toggle"){

		xhttpObj.open("GET",contextpath+"/preauth/doSearchInsComp?"+parameters+"&sortId="+sessionStorage.getItem("sortId"), false);
	}

	else{
		xhttpObj.open("GET",contextpath+"/preauth/doSearchInsComp?"+parameters, false);

	}
	xhttpObj.send();
	var sData=xhttpObj.responseText;
	if(sData!==null&&sData!==""&&sData.length>1){

		document.getElementById("inscompTableGrid").innerHTML =sData;


	}else{

		document.getElementById("inscompTableGrid").innerHTML ="";

	} 

	sessionStorage.setItem("pageIndexsearch","");
	sessionStorage.setItem("pageId","");
	sessionStorage.setItem("sortId","");

}//end of onSearchInsCom()
/*
function onSearchCorpCom()
{		
alert("ajax call");
	var parameters="groupID="+document.forms["genForm"].groupID.value+"&"+
	"groupName="+document.forms["genForm"].groupName.value+"&"+
	"branchName="+document.forms["genForm"].branchName.value;

	var xhttpObj=null;
	if(xhttpObj==null){	
		if (window.XMLHttpRequest) {
			// code for modern browsers
			xhttpObj = new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	document.getElementById("corpcompTableGrid").innerHTML ="";

	if(sessionStorage.getItem("pageIndexsearch")==="pageindex"){
		xhttpObj.open("GET",contextpath+"/preauth/doSearchCorpComp?"+parameters+"&pageId="+sessionStorage.getItem("pageId"), false);
	}else if(sessionStorage.getItem("pageIndexsearch")==="toggle"){

		xhttpObj.open("GET",contextpath+"/preauth/doSearchCorpComp?"+parameters+"&sortId="+sessionStorage.getItem("sortId"), false);
	}

	else{
		xhttpObj.open("GET",contextpath+"/preauth/doSearchCorpComp?"+parameters, false);

	}
	xhttpObj.send();
	var sData=xhttpObj.responseText;
	if(sData!==null&&sData!==""&&sData.length>1){
alert("date..."+sData);
		document.getElementById("corpcompTableGrid").innerHTML =sData;


	}else{

		document.getElementById("corpcompTableGrid").innerHTML ="";

	} 

	sessionStorage.setItem("pageIndexsearch","");
	sessionStorage.setItem("pageId","");
	sessionStorage.setItem("sortId","");

}//end of onSearchInsCom()
*/

function onHosSearch()
{	
	var parameters="hospitalLocation="+document.forms["genForm"].hospitalLocation.value+"&"+
	"stateId="+document.forms["genForm"].stateId.value+"&"+
	"cityID="+document.forms["genForm"].cityID.value+"&"+
	"hospName="+document.forms["genForm"].hospName.value+"&"+
	"hospEmpannelmentNum="+document.forms["genForm"].hospEmpannelmentNum.value+"&"+
	"hospRohiniId="+document.forms["genForm"].hospRohiniId.value+"&"+
	"lngPolicySeqID="+document.getElementById("lngPolicySeqID").value+"&"+
	"paymentType="+document.forms["genForm"].paymentType.value+"&"+
	"GroupID="+document.getElementById("groupID").value;
	
	var xhttpObj=null;
	if(xhttpObj==null){	
		if (window.XMLHttpRequest) {
			// code for modern browsers
			xhttpObj = new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	//clearing data before populating ajax response
	document.getElementById("hospitalTableGrid").innerHTML ="";

	if(sessionStorage.getItem("pageIndexsearch")==="pageindex"){
		xhttpObj.open("GET",contextpath+"/preauth/doSearchHospital?"+parameters+"&pageId="+sessionStorage.getItem("pageId"), false);
	}else if(sessionStorage.getItem("pageIndexsearch")==="toggle"){

		xhttpObj.open("GET",contextpath+"/preauth/doSearchHospital?"+parameters+"&sortId="+sessionStorage.getItem("sortId"), false);
	} else{
		xhttpObj.open("GET",contextpath+"/preauth/doSearchHospital?"+parameters, false);
	}
	xhttpObj.send();
	var sData=xhttpObj.responseText;
	if(sData!==null&&sData!==""&&sData.length>1){

		document.getElementById("hospitalTableGrid").innerHTML =sData;


	}else{

		document.getElementById("hospitalTableGrid").innerHTML ="";

	}  	

	sessionStorage.setItem("pageIndexsearch","");
	sessionStorage.setItem("pageId","");
	sessionStorage.setItem("sortId","");

}//end of do search hospital 





function toggle(sortid,sparam)
{	

	sessionStorage.setItem("pageIndexsearch", "toggle");
	sessionStorage.setItem("sortId",sortid);

	if(sparam == "politableData")
	{
		onSearchPolicy();
	}
	if(sparam == "InsuComptableData")
	{
		onSearchInsCom();
	}
	if(sparam == "hosptableData")
	{
		onHosSearch();

	}
	if(sparam == "enrtableData")
	{
		onEnrollSearch();
	}  

}//end of toggle(sortid)



function pageIndex(pagenumber,sparam)
{

	sessionStorage.setItem("pageIndexsearch", "pageindex");
	sessionStorage.setItem("pageId",pagenumber);

	if(sparam == "politableData")
	{
		onSearchPolicy();
	}
	if(sparam == "InsuComptableData")
	{
		onSearchInsCom();
	}
	if(sparam == "hosptableData")
	{
		onHosSearch();

	}
	if(sparam == "enrtableData")
	{
		onEnrollSearch();
	}  


}//end of pageIndex




/*function edit(rownum,sparam)
{
	if(sparam == "politableData")
	{
		document.forms["genForm"].rownum.value=rownum;
		document.forms["genForm"].action=contextpath+"/preauth/preauthpolidetailsview";
		document.forms["genForm"].submit();
	}
	if(sparam == "InsuComptableData")
	{
		document.forms["genForm"].rownum.value=rownum;
		document.forms["genForm"].action=contextpath+"/preauth/preauthInsudetailsview";
		document.forms["genForm"].submit();
	}
	if(sparam == "hosptableData")
	{

		document.forms["genForm"].rownum.value=rownum;
		document.forms["genForm"].action=contextpath+"/preauth/preauthHospdetailsview";
		document.forms["genForm"].submit();

	}
	if(sparam == "enrtableData")
	{

		document.forms["genForm"].rownum.value=rownum;
		document.forms["genForm"].action=contextpath+"/preauth/claimentdetailspopulation";
		document.forms["genForm"].submit();
	}
	if(sparam == "CorpComptableData"){
		alert("test..."+sparam);
		alert("test..."+rownum)
		
	}

}*/


function PressForward(sparam)
{

	if(sparam == "enrtableData")
	{
	var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("enrollementTableGrid").innerHTML ="PLease WAIT   ........";
		xhttpObj.open("GET",contextpath+"/preauth/forwardEnrollSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){

			document.getElementById("enrollementTableGrid").innerHTML =sData;
		}else{
			document.getElementById("enrollementTableGrid").innerHTML ="";
		}

	}//end of   if(sparam == "enrtableData")
	if(sparam == "hosptableData")
	{
		var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("hospitalTableGrid").innerHTML ="";
		xhttpObj.open("GET",contextpath+"/preauth/forwardHospSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){
			document.getElementById("hospitalTableGrid").innerHTML =sData;
		}else{
			document.getElementById("hospitalTableGrid").innerHTML ="";
		}

	}
	if(sparam == "politableData")
	{
		var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("policyTableGrid").innerHTML ="";
		xhttpObj.open("GET",contextpath+"/preauth/forwardPoliSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){

			document.getElementById("policyTableGrid").innerHTML =sData;
		}else{
			document.getElementById("policyTableGrid").innerHTML ="";

		}

	}
	if(sparam == "InsuComptableData")
	{

		var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("inscompTableGrid").innerHTML ="";
		xhttpObj.open("GET",contextpath+"/preauth/forwardInsuSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){

			document.getElementById("inscompTableGrid").innerHTML =sData;


		}else{

			document.getElementById("inscompTableGrid").innerHTML ="";

		}  


	}

}//end of forward
function PressBackWard(sparam){

	if(sparam == "enrtableData")
	{

		var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("enrollementTableGrid").innerHTML ="";
		xhttpObj.open("GET",contextpath+"/preauth/backwordEnrollSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){

			document.getElementById("enrollementTableGrid").innerHTML =sData;


		}else{

			document.getElementById("enrollementTableGrid").innerHTML ="";

		} 

	}//end of  if(sparam == "enrtableData")

	if(sparam == "hosptableData")
	{

		var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("hospitalTableGrid").innerHTML ="";
		xhttpObj.open("GET",contextpath+"/preauth/backwordHospSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){

			document.getElementById("hospitalTableGrid").innerHTML =sData;


		}else{

			document.getElementById("hospitalTableGrid").innerHTML ="";

		} 

	}
	if(sparam == "politableData")
	{
		var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("policyTableGrid").innerHTML ="";
		xhttpObj.open("GET",contextpath+"/preauth/backwordPoliSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){

			document.getElementById("policyTableGrid").innerHTML =sData;


		}else{

			document.getElementById("policyTableGrid").innerHTML ="";

		}


	}
	if(sparam == "InsuComptableData")
	{


		var xhttpObj=null;
		if(xhttpObj==null){	
			if (window.XMLHttpRequest) {
				// code for modern browsers
				xhttpObj = new XMLHttpRequest();
			} else {
				// code for IE6, IE5
				xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
		document.getElementById("inscompTableGrid").innerHTML ="";
		xhttpObj.open("GET",contextpath+"/preauth/backwordInsuSearch", false);
		xhttpObj.send();
		var sData=xhttpObj.responseText;
		if(sData!==null&&sData!==""&&sData.length>1){

			document.getElementById("inscompTableGrid").innerHTML =sData;


		}else{

			document.getElementById("inscompTableGrid").innerHTML ="";

		}  


	}

}//end od backward


function onChangeState()
{
	document.forms["genForm"].action = contextpath+"/preauth/onChangeState";
	document.forms["genForm"].submit();

}

function onSelectState(stateId) {
	var stateid =stateId;
	if(stateid == ''){
		$('#cityID')[0].options.length = 0;
		$("#cityID").prepend("<option value='' selected='selected'>City</option>");
		return false;
	}else{
		var path="doCityList.htm?stateId="+stateid+""; 

		$.ajax({
			url :path,
			success : function(data) { 
				var myselect1=document.getElementById("cityID");
				while (myselect1.hasChildNodes()) {   
					myselect1.removeChild(myselect1.firstChild);
				}    
				// myselect1.options.add(new Option("City",""));
				var res1 = data.split("#");	     
				for(var i=0;i<res1.length-1;i++){	
					var code=res1[i].split("@");	    
					myselect1.options.add(new Option(code[1],code[0]));
				}
				var options = $("#cityID option");                    // Collect options         
				options.detach().sort(function(a,b) {               // Detach from select, then Sort
					var at = $(a).text();
					var bt = $(b).text();         
					return (at > bt)?1:((at < bt)?-1:0);            // Tell the sort function how to order
				});
				options.appendTo("#cityID");
				$("#cityID").prepend("<option value='' selected='selected'>City</option>");

			}
		});
	}
}

function clearEnrollmentID(){
	
	document.forms["genForm"].action=contextpath+"/preauth/clearclaimentdetails";
	document.forms["genForm"].submit();


}
function clearPolicy(){

	document.forms["genForm"].action=contextpath+"/preauth/clearpolicydetails";
	document.forms["genForm"].submit();

	}

function clearHospitalDeatils(){

	document.forms["genForm"].action=contextpath+"/preauth/clearhospitaldetails";
	document.forms["genForm"].submit();

	}

function selectageID(){
var gender=$("#genderId").val();

}

