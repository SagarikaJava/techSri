
function selectAll(bChkd)
{
	for(var i=0;i<document.forms["searchPreauth"].length;i++)
	{
		if(document.forms["searchPreauth"].elements[i].name == "chkopt" && document.forms["searchPreauth"].elements[i].disabled==false)
		{
			document.forms["searchPreauth"].elements[i].checked = bChkd;
		}
	}
}//end of selectAll(bChkd)


function copyToWebBoard()
{
    if(!mChkboxValidation(document.forms["searchPreauth"]))
    {
    	 document.forms["searchPreauth"].action =contextpath+"/preauth/copyPreauthToClipBoard";
 	    document.forms["searchPreauth"].submit(); 
    }//end of if(!mChkboxValidation(document.forms[1]))
}//end of copyToWebBoard()

function mChkboxValidation(obj)
{
	with(obj)
	{
		for(var i=0;i<elements.length;i++)
		{
			if(elements[i].type=="checkbox" && elements[i].name!="chkAll")
			{
				if (elements[i].checked)
				{
					iFlag = 1;
					break;
				}
				else
				{
					iFlag = 0;
				}
			}
		}
	}

	if (iFlag == 0)
	{
		swal('Please select atleast one record');
		return true;
	}
	else
	{
		return false;
	}
}//end of mChkboxValidation

	function toggle(sortid)
	{		
	    $('#sortId').val(sortid);
	    document.getElementById('sortId').value = sortid;
	    $("#searchPreauth").submit();
	      document.forms["searchPreauth"].action =contextpath+"/preauth/preauthsearch";
		   JS_SecondSubmit=true;
		    document.forms["searchPreauth"].submit();
	
	  
	}//end of toggle(sortid)
	function pageIndex(pagenumber)
	{		
	    $('#pageId').val(pagenumber);
	    document.getElementById('pageId').value = pagenumber;	    
	     document.forms["searchPreauth"].action =contextpath+"/preauth/preauthsearch";
		    document.forms["searchPreauth"].submit();	    
	}
	//"${rootPath}/preauth/search1.html"
	function onSearchPreauth(sparam)
	{			
	    document.forms["searchPreauth"].action =contextpath+"/preauth/preauthsearch";
	    document.getElementById("mysearch").innerHTML ="";
        document.getElementById("mysearch").innerHTML = "Please Wait....";        
        document.getElementById("seaerchType").value =sparam;
		JS_SecondSubmit=true;
	    document.forms["searchPreauth"].submit();
	}
	
	function onSearchPreauthPanel(sparam)
	{			
	    document.forms["searchPreauth"].action =contextpath+"/preauth/preauthsearch";	    
        document.getElementById("mysearch1").innerHTML ="";
        document.getElementById("mysearch1").innerHTML = "Please Wait...."; 
        document.getElementById("seaerchType").value =sparam;
		JS_SecondSubmit=true;		 
	    document.forms["searchPreauth"].submit();	    	    
	}
	
	function onStatus()
	{	
		//document.forms["searchPreauth"].reset();
	    document.forms["searchPreauth"].action ="preauthsearch";
	    document.forms["searchPreauth"].submit(); 
	    
	}
// 	$(document).ready(function(){
// 	       $("#b1b1").click(function(){
//            $("#searchPreauth").submit(function(){
        	   
//            });
//  	       });
//             });

 	function PressBackWard(){
 		//document.forms["searchPreauth"].reset();
 		document.forms["searchPreauth"].action=contextpath+"/preauth/backwarpreauthsearch";
 		document.forms["searchPreauth"].submit();	
 	}
	
 	function addPreAuth()
 	{
 		//document.forms["searchPreauth"].reset();
 	    document.forms["searchPreauth"].rownum.value = "";
 	    document.forms["searchPreauth"].action = contextpath+"/preauth/preauthdetailsview";
 	    document.forms["searchPreauth"].submit();
 	}
 	
function PressForward()
 	{
 	   // document.forms["searchPreauth"].reset();
		document.forms["searchPreauth"].action=contextpath+"/preauth/forwardpreauthsearch";
		document.forms["searchPreauth"].submit();	
	}
 	
function edit(rownum)
    {
	document.forms["searchPreauth"].rownum.value=rownum;
	document.forms["searchPreauth"].action=contextpath+"/preauth/preauthdetailsview";
	document.forms["searchPreauth"].submit();	
    }

function onPreauthStaus(clickStatus){
	
	document.forms["searchPreauth"].action = contextpath+"/preauth/preauthsearchdashboard?clickStatus="+clickStatus;
	document.forms["searchPreauth"].submit();
	
}

function onStatus(){
	document.forms["searchPreauth"].action = contextpath+"/preauth/preauthsearch";
	document.forms["searchPreauth"].submit();
}

/*function AlertSearch(){
		//document.forms["searchPreauth"].reset();
		document.forms["searchPreauth"].action=contextpath+"/Pre-Authorization/AlertSearch";
		document.forms["searchPreauth"].submit();	
	}*/
function onAlertSearch()
{
	
	
document.forms["AlertForm"].action = "/vingsproject/Pre-Authorization/AlertSearch";
            document.forms["AlertForm"].submit();

}
function onAlertSave()
{
	var remark=$("#logDesc").val();
	if(remark !=null && remark != "" && remark !=''){
		document.forms["AlertForm"].action = "/vingsproject/Pre-Authorization/Save";
        document.forms["AlertForm"].submit();
	}else{
		alert("Enter the remark");
	}
	

}
function closeMsg(){
	$("#logDesc").val("");
	$("#logtypeid1").val("NAR");
	$(".cpopBox").hide();
	
	

}
