package com.vidal.redis.resource;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vidal.redis.dao.UserRepository;
import com.vidal.redis.model.User;

@RestController
@RequestMapping("/rest/user")
public class UserResource {
	
	private UserRepository repository;
	
	public UserResource(UserRepository repository) {
		this.repository = repository;
	}
	/* Save particular user and get */
	@GetMapping("/add/{id}/{name}")
	public User addUser(@PathVariable("id") String id,@PathVariable("name") String name){
		repository.save(new User(id, name, 45000L));
		return repository.findById(id);
	}
	/* update particular user and get */
	@GetMapping("/update/{id}/{name}")
	public User update(@PathVariable("id") String id,@PathVariable("name") String name){
		repository.update(new User(id, name, 60000L));
		return repository.findById(id);
	}
	/* get all user */
	@GetMapping("/findall")
	public Map<String, User> findAll(){
		return repository.findAll();
	}
	/* delete particular user and get */
	@GetMapping("/delete/{id}")
	public Map<String, User> delete(@PathVariable("id") String id){
		 repository.delete(id);
		 return findAll();
	}
}
