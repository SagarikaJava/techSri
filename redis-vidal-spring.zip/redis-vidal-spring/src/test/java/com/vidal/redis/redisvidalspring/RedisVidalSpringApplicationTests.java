package com.vidal.redis.redisvidalspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisVidalSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
